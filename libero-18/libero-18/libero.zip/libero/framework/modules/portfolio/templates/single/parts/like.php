<div class="mkd-like-holder">
    <?php echo libero_mikado_like_portfolio_post(get_the_ID()); ?>
</div>