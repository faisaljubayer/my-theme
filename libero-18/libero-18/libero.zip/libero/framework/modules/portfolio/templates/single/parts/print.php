<div class="mkd-print-holder">
    <a href="#" onClick="window.print();return false;" class="mkd-print-page">
        <span class="icon-printer mkd-icon-printer"></span>
        <span class="mkd-printer-title"><?php esc_html_e("Print", "libero") ?></span>
    </a>
</div>