<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/blog-list/blog-list.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/blog-list/custom-styles/blog-list.php';