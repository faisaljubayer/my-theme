<?php

//Get search HTML
add_action('libero_mikado_before_page_header', 'libero_mikado_get_search', 9);