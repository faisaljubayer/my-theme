<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/image-slider/image-slider.php';
