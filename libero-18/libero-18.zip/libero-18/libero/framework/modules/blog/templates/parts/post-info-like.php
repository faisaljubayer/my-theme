<div class="mkd-blog-like">
	<?php if( function_exists('libero_mikado_get_like') ) libero_mikado_get_like(); ?>
</div>